import { state } from '../game/state.js';
import { getCookStatus } from '../game/rules.js';
import { LAYOUT, getVisualPalette, getLaneBounds, getButtonBounds, ICON_DATA } from './layout.js';
import { isPlayerInputLocked, canSelectAction, isLaneValidForAction } from '../game/input.js';

const getTime = () => performance.now();
const getWave = (speed, offset = 0) => Math.sin(getTime() * speed + offset);

// ドットアイコン描画関数
function drawDotIcon(ctx, iconId, cx, cy, color, scale = 4) {
    const data = ICON_DATA[iconId];
    if (!data) return;
    ctx.fillStyle = color;
    for (let i = 0; i < 64; i++) {
        if (data[i] === 1) {
            const x = (i % 8) * scale;
            const y = Math.floor(i / 8) * scale;
            ctx.fillRect(cx - (4 * scale) + x, cy - (4 * scale) + y, scale, scale);
        }
    }
}

export function render(ctx) {
    const now = getTime();
    state.visuals.ghosts = state.visuals.ghosts.filter(g => now - g.startTime < 1000);
    state.visuals.floaters = state.visuals.floaters.filter(f => now - f.startTime < 800);

    ctx.fillStyle = LAYOUT.COLORS.BG;
    ctx.fillRect(0, 0, LAYOUT.CANVAS_WIDTH, LAYOUT.CANVAS_HEIGHT);

    if (state.screen === "title") drawTitleScreen(ctx);
    else if (state.screen === "game") drawGameScreen(ctx);
    else if (state.screen === "gameover") drawGameOverScreen(ctx);
}

function drawTitleScreen(ctx) {
    ctx.fillStyle = LAYOUT.COLORS.TEXT_MAIN;
    ctx.font = "40px monospace";
    ctx.textAlign = "center";
    ctx.fillText("YAKITORI WARS", LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2 - 50);
    ctx.font = "24px monospace";
    ctx.fillStyle = (Math.floor(Date.now() / 500) % 2 === 0) ? LAYOUT.COLORS.TEXT_MAIN : LAYOUT.COLORS.TEXT_DIM;
    ctx.fillText("Click to Start: SURVIVAL", LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2 + 50);
}

function drawGameOverScreen(ctx) {
    ctx.fillStyle = LAYOUT.COLORS.TEXT_MAIN;
    ctx.font = "40px monospace";
    ctx.textAlign = "center";
    ctx.fillText("GAME OVER", LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2 - 50);
    ctx.fillStyle = state.winner === "P1" ? LAYOUT.COLORS.P1 : (state.winner === "P2" ? LAYOUT.COLORS.P2 : LAYOUT.COLORS.TEXT_MAIN);
    ctx.fillText(`WINNER: ${state.winner}`, LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2 + 20);
    ctx.font = "20px monospace";
    ctx.fillStyle = LAYOUT.COLORS.TEXT_DIM;
    ctx.fillText("Click to return Title", LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2 + 80);
}

function drawGameScreen(ctx) {
    drawTopBar(ctx);
    state.lanes.forEach((lane, i) => {
        const bounds = getLaneBounds(i);
        drawLane(ctx, lane, bounds, i);
    });
    drawActionButtons(ctx);
    drawVisualEffects(ctx);
    drawOverlay(ctx);
}

function drawTopBar(ctx) {
    drawPlayerPanel(ctx, state.players[0], 20, 20, 140, 70, 1);
    ctx.fillStyle = LAYOUT.COLORS.PANEL_BG;
    ctx.fillRect(180, 20, 440, 50);
    ctx.strokeStyle = LAYOUT.COLORS.NEUTRAL;
    ctx.strokeRect(180, 20, 440, 50);
    
    ctx.fillStyle = LAYOUT.COLORS.TEXT_MAIN;
    ctx.font = "bold 24px monospace";
    ctx.textAlign = "center";
    ctx.fillText(`ROUND  ${state.round}`, LAYOUT.CANVAS_WIDTH / 2, 53);
    if (state.enemyName) {
        ctx.font = "18px monospace";
        ctx.fillText(state.enemyName, LAYOUT.CANVAS_WIDTH / 2, 100);
    }
    drawPlayerPanel(ctx, state.players[1], 640, 20, 140, 70, 2);
}

function drawPlayerPanel(ctx, player, x, y, w, h, playerIndex) {
    const isActive = (state.currentPlayer === playerIndex);
    const pColor = playerIndex === 1 ? LAYOUT.COLORS.P1 : LAYOUT.COLORS.P2;
    
    ctx.fillStyle = LAYOUT.COLORS.PANEL_BG;
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = isActive ? pColor : LAYOUT.COLORS.NEUTRAL;
    ctx.lineWidth = isActive ? 3 : 2;
    ctx.strokeRect(x, y, w, h);

    ctx.fillStyle = pColor;
    ctx.font = "bold 20px monospace";
    ctx.textAlign = "center";
    ctx.fillText(`P${playerIndex}`, x + w / 2, y + 25);
    ctx.fillStyle = LAYOUT.COLORS.TEXT_MAIN;
    ctx.font = "14px monospace";
    ctx.fillText(`SCORE: ${player.score}`, x + w / 2, y + 45);
    ctx.fillText(`MEAT : ${player.meat}`, x + w / 2, y + 60);
}

export function drawActionButtons(ctx) {
    const isLocked = isPlayerInputLocked();
    const now = getTime();

    LAYOUT.BUTTONS.forEach((btn, i) => {
        let {x, y, w, h} = getButtonBounds(i);
        const canUse = canSelectAction(btn.id) && !isLocked;
        const isSelected = (state.buildMode === btn.id);
        
        const tClick = now - (state.visuals.buttonClicks[btn.id] || 0);
        const tErr = now - (state.visuals.buttonErrors[btn.id] || 0);

        ctx.save();
        
        // エラー時の横振動
        if (tErr < 300) {
            x += Math.sin(tErr * 0.1) * 2;
        }

        // クリック時の沈み込みとスケール
        let isPressed = false;
        if (tClick < 100) {
            const scale = 0.95;
            ctx.translate(x + w/2, y + h/2);
            ctx.scale(scale, scale);
            ctx.translate(-(x + w/2), -(y + h/2));
            y += 2; // Y方向に沈む
            isPressed = true;
        }

        // 無効状態の彩度低下
        ctx.fillStyle = canUse ? btn.color : "#445";
        ctx.fillRect(x, y, w, h);
        
        ctx.lineWidth = isSelected ? 4 : 2;
        ctx.strokeStyle = isSelected ? "#fff" : "#222";
        ctx.strokeRect(x, y, w, h);

        // クリック時の発光
        if (isPressed) {
            ctx.fillStyle = "rgba(255,255,255,0.3)";
            ctx.fillRect(x, y, w, h);
        }

        // ドットアイコンの描画
        const iconColor = canUse ? "#fff" : "#778";
        drawDotIcon(ctx, btn.icon, x + w/2, y + h/2, iconColor, 5);
        
        ctx.restore();
    });
}

export function drawLane(ctx, lane, bounds, index) {
    let {x, y, w, h} = bounds;
    const now = getTime();
    const tErr = now - (state.visuals.laneErrors[index] || 0);

    ctx.save();
    
    // RAW失敗時の青い小さな震え
    if (tErr < 300) {
        x += Math.sin(tErr * 0.1) * 3;
        ctx.fillStyle = "rgba(100, 150, 255, 0.2)";
        ctx.fillRect(x, y, w, h);
    }

    const cx = x + w / 2;
    drawLaneBase(ctx, x, y, w, h, index);

    // 選択時のフラッシュ
    const tFlash = now - (state.visuals.laneFlashes[lane.id] || 0);
    if (tFlash < 150) {
        ctx.fillStyle = `rgba(255, 255, 255, ${0.5 - (tFlash / 150) * 0.5})`;
        ctx.fillRect(x, y, w, h);
    }

    drawFireIcons(ctx, lane, cx, y + h - 15);
    
    if (lane.owner !== null) {
        const status = getCookStatus(lane);
        const palette = getVisualPalette(status);
        
        drawOwnerMarker(ctx, lane, cx, y + 15);
        drawSkewer(ctx, lane, palette, cx, y + h / 2);
        
        // 状態エフェクト
        if (palette.effect === "spark") drawSparks(ctx, cx, y + h / 2);
        if (palette.effect === "smoke") drawSmoke(ctx, cx, y + h / 2 - 20, true);
        
        drawCookDots(ctx, lane, palette, cx + 40, y + h / 2 - 10);
    }
    ctx.restore();
}

function drawLaneBase(ctx, x, y, w, h, index) {
    ctx.fillStyle = LAYOUT.COLORS.PANEL_BG;
    ctx.fillRect(x, y, w, h);
    if (state.buildMode && isLaneValidForAction(index, state.buildMode)) {
        ctx.fillStyle = LAYOUT.COLORS.HIGHLIGHT;
        ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = "white";
    } else {
        ctx.strokeStyle = LAYOUT.COLORS.NEUTRAL;
    }
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
}

function drawFireIcons(ctx, lane, cx, bottomY) {
    const fireCount = lane.fire;
    const isBoosted = lane.uchiwaBoost > 0;
    const fireColor = isBoosted ? LAYOUT.COLORS.FIRE_BOOST : LAYOUT.COLORS.FIRE_BASE;
    let baseSize = isBoosted ? 14 : 10;
    if (isBoosted) baseSize += getWave(0.015) * 2;
    const spacing = 20;
    const startX = cx - ((fireCount - 1) * spacing) / 2;
    ctx.fillStyle = fireColor;
    for (let i = 0; i < fireCount; i++) {
        const fx = startX + i * spacing;
        const waveY = getWave(0.01, i * 2) * 3;
        const waveX = getWave(0.015, i * 3) * 1.5;
        ctx.beginPath();
        ctx.moveTo(fx, bottomY - (baseSize + waveY));
        ctx.lineTo(fx - (baseSize / 1.5 + waveX), bottomY);
        ctx.lineTo(fx + (baseSize / 1.5 + waveX), bottomY);
        ctx.fill();
    }
}

function drawSkewer(ctx, lane, palette, cx, cy) {
    const tPut = getTime() - (state.visuals.placedAt[lane.id] || 0);
    let scale = 1.0;
    if (tPut < 200) {
        const p = tPut / 200;
        scale = 0.5 + Math.sin(p * Math.PI / 2) * 0.6; 
    }

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.translate(-cx, -cy);

    ctx.fillStyle = LAYOUT.COLORS.STICK;
    ctx.fillRect(cx - 2, cy - 35, 4, 75);
    let glowAlpha = palette.effect === "spark" ? 0.5 + getWave(0.008) * 0.4 : 0.5;
    
    const drawBlock = (yOffset, color, isBurnt, isGlow) => {
        ctx.fillStyle = color;
        ctx.fillRect(cx - 15, cy + yOffset, 30, 16);
        if (isGlow) {
            ctx.strokeStyle = `rgba(255, 255, 200, ${glowAlpha})`;
            ctx.lineWidth = 2;
            ctx.strokeRect(cx - 14, cy + yOffset + 1, 28, 14);
        }
        if (isBurnt) {
            ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
            ctx.fillRect(cx - 10, cy + yOffset + 4, 8, 4);
            ctx.fillRect(cx + 2, cy + yOffset + 8, 6, 4);
        }
    };
    
    const isBurnt = palette.effect === "smoke";
    const isGlow = palette.effect === "spark";
    
    drawBlock(-25, palette.meat, isBurnt, isGlow);
    drawBlock(-5, palette.negi, isBurnt, isGlow);
    drawBlock(15, palette.meat, isBurnt, isGlow);
    
    ctx.restore();
}

function drawSparks(ctx, cx, cy) {
    const t = getTime();
    if (t % 200 < 100) return; // 点滅
    ctx.fillStyle = "#ff4";
    ctx.fillRect(cx - 30 + Math.random()*60, cy - 20 + Math.random()*40, 4, 4);
    ctx.fillStyle = "#fff";
    ctx.fillRect(cx - 30 + Math.random()*60, cy - 20 + Math.random()*40, 4, 4);
}

function drawSmoke(ctx, cx, startY, blinkRed = false) {
    const t = getTime();
    
    // 赤点滅 (BURNT)
    if (blinkRed && t % 300 < 150) {
        ctx.fillStyle = "rgba(255, 0, 0, 0.4)";
        ctx.fillRect(cx - 20, startY, 40, 40);
    }
    
    for (let i = 0; i < 2; i++) {
        const progress = ((t + i * 750) % 1500) / 1500;
        ctx.fillStyle = `rgba(50, 50, 50, ${(1.0 - progress) * 0.6})`;
        ctx.beginPath();
        ctx.arc(cx + Math.sin(progress * Math.PI * 2) * 8, startY - progress * 30, 4 + progress * 8, 0, Math.PI * 2);
        ctx.fill();
    }
}

export function drawCookDots(ctx, lane, palette, startX, startY) {
    const isWeak = (lane.type === "weak");
    const cv = lane.cook;
    
    for (let i = 0; i < 6; i++) {
        let dotColor = i < Math.min(cv, 6) ? palette.dot : LAYOUT.COLORS.DOT_OFF;
        
        // Weakレーンの「2段階光る」表現
        if (isWeak && i >= 5 && cv >= 6 && cv < 8) {
            if (getTime() % 400 < 200) dotColor = "#fff"; 
        }
        
        ctx.fillStyle = dotColor;
        ctx.fillRect(startX + (i % 2) * 10, startY - Math.floor(i / 2) * 10, 6, 6);
    }
}

function drawOwnerMarker(ctx, lane, cx, topY) {
    const drawY = topY + getWave(0.005, lane.fire) * 3;
    ctx.fillStyle = lane.owner === 1 ? LAYOUT.COLORS.P1 : LAYOUT.COLORS.P2;
    ctx.beginPath();
    ctx.moveTo(cx - 6, drawY);
    ctx.lineTo(cx + 6, drawY);
    ctx.lineTo(cx, drawY + 8);
    ctx.fill();
}

export function drawVisualEffects(ctx) {
    const now = getTime();
    
    // Serve時のフェードアウトする串
    state.visuals.ghosts.forEach(g => {
        const t = now - g.startTime;
        if (t < 500) {
            const bounds = getLaneBounds(g.laneIndex);
            const cx = bounds.x + bounds.w / 2;
            const cy = bounds.y + bounds.h / 2;
            const yOffset = -(t * 0.15);
            ctx.globalAlpha = 1.0 - (t / 500);
            
            drawSkewer(ctx, {id: "ghost", justPlaced: false}, getVisualPalette(g.status), cx, cy + yOffset);
            ctx.globalAlpha = 1.0;
        }
    });

    // アイコンの浮遊エフェクト
    state.visuals.floaters.forEach(f => {
        const t = now - f.startTime;
        if (t < 600) { 
            let x = 0, y = 0;
            if (f.targetType === 'p1') { x = 90; y = 70; }
            else if (f.targetType === 'p2') { x = LAYOUT.CANVAS_WIDTH - 90; y = 70; }
            else if (f.targetType === 'lane') {
                const bounds = getLaneBounds(f.targetIndex);
                x = bounds.x + bounds.w / 2 + 60;
                y = bounds.y + bounds.h / 2;
            }
            
            const progress = t / 600;
            ctx.globalAlpha = 1.0 - progress;

            if (f.type === 'meat_up') {
                drawDotIcon(ctx, 'meat', x, y - (progress * 30), "#c55", 3);
            } else if (f.type === 'meat_down') {
                const gravityY = Math.pow(progress, 2) * 50; 
                drawDotIcon(ctx, 'meat', x, y + gravityY, "#c55", 3);
            } else if (f.type === 'star_up') {
                // スコア上昇はスパークで表現
                drawSparks(ctx, x, y - (progress * 30));
            }
            ctx.globalAlpha = 1.0;
        }
    });
}

function drawOverlay(ctx) {
    if (state.turnSplashTimer > 0) {
        const progress = state.turnSplashTimer / 90;
        let alpha = 1.0;
        if (progress > 0.8) alpha = (1.0 - progress) / 0.2;
        else if (progress < 0.2) alpha = progress / 0.2;

        ctx.fillStyle = `rgba(0, 0, 0, ${alpha * 0.7})`;
        ctx.fillRect(0, 0, LAYOUT.CANVAS_WIDTH, LAYOUT.CANVAS_HEIGHT);
        
        // ターン切り替えテキストはそのまま残しています
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.font = "bold 48px monospace";
        ctx.textAlign = "center";
        ctx.fillText("NEXT CHEF", LAYOUT.CANVAS_WIDTH / 2, LAYOUT.CANVAS_HEIGHT / 2);
    } else if (state.isBusy && state.currentPlayer === 2 && state.aiBreathTimer === 0) {
        // AI思考中
        ctx.fillStyle = LAYOUT.COLORS.P2;
        ctx.font = "italic 24px monospace";
        ctx.textAlign = "center";
        ctx.fillText("Thinking...", LAYOUT.CANVAS_WIDTH / 2, 140);
    }
}