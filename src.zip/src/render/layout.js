export const LAYOUT = {
  CANVAS_WIDTH: 800,
  CANVAS_HEIGHT: 600,
  
  COLORS: {
      BG: "#161620", 
      TEXT_MAIN: "#fff",
      TEXT_DIM: "#aaa",
      P1: "#3c96ff",
      P2: "#ff5078",
      NEUTRAL: "#333",
      PANEL_BG: "#242430",
      OVERLAY_BG: "rgba(0, 0, 0, 0.7)",
      STICK: "#dca",
      FIRE_BASE: "#e53",
      FIRE_BOOST: "#fa3",
      DOT_OFF: "#334",
      HIGHLIGHT: "rgba(255, 255, 255, 0.4)"
  },

  // テキストラベルを廃止し、アイコンIDを指定
  BUTTONS: [
      { id: "meat", color: "#c55", icon: "meat" },
      { id: "put", color: "#678", icon: "put" },
      { id: "harvest", color: "#484", icon: "serve" },
      { id: "uchiwa", color: "#d63", icon: "uchiwa" }
  ]
};

// 視覚状態の定義（テキストを使わず色とエフェクトで表現）
export const VISUAL_STATES = {
  RAW: { meat: "#ddd", negi: "#bdf", dot: "#fff", effect: "none" },
  OKAY: { meat: "#853", negi: "#683", dot: "#f90", effect: "none" },
  PERFECT: { meat: "#da4", negi: "#8e2", dot: "#ff4", effect: "spark" },
  BURNT: { meat: "#222", negi: "#111", dot: "#f33", effect: "smoke" }
};

export function getVisualPalette(status) {
  return VISUAL_STATES[status] || VISUAL_STATES.RAW;
}

// 8x8の簡易ドット絵データ (1:色あり, 0:透明)
export const ICON_DATA = {
  meat: [
    0,0,1,1,1,1,0,0,
    0,1,1,1,1,1,1,0,
    1,1,1,1,1,1,1,1,
    0,1,1,1,1,1,1,0,
    0,1,1,1,1,1,1,0,
    0,0,1,1,1,1,0,0,
    1,0,0,0,0,0,0,1,
    0,1,0,0,0,0,1,0
  ],
  put: [
    0,0,0,1,1,0,0,0,
    0,0,0,1,1,0,0,0,
    0,0,0,1,1,0,0,0,
    1,1,1,1,1,1,1,1,
    0,1,1,1,1,1,1,0,
    0,0,1,1,1,1,0,0,
    0,0,0,1,1,0,0,0,
    0,0,0,0,0,0,0,0
  ],
  serve: [
    0,0,1,1,1,1,0,0,
    0,1,1,1,1,1,1,0,
    1,1,0,1,1,0,1,1,
    1,1,1,1,1,1,1,1,
    1,1,0,1,1,0,1,1,
    0,1,1,1,1,1,1,0,
    0,0,1,1,1,1,0,0,
    0,0,0,0,0,0,0,0
  ],
  uchiwa: [
    0,1,1,1,1,1,1,0,
    1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,
    0,1,1,1,1,1,1,0,
    0,0,0,1,1,0,0,0,
    0,0,0,1,1,0,0,0,
    0,0,0,1,1,0,0,0
  ]
};

export function getLaneBounds(index) {
  const w = 600;
  const h = 90;
  const x = (LAYOUT.CANVAS_WIDTH - w) / 2;
  const y = 170 + index * (h + 15);
  return { x, y, w, h };
}

export function getButtonBounds(index) {
  const count = LAYOUT.BUTTONS.length;
  const w = 120; // ドットUIに合わせて少しコンパクトに
  const h = 80;
  const gap = 20;
  const totalW = (w * count) + (gap * (count - 1));
  const startX = (LAYOUT.CANVAS_WIDTH - totalW) / 2;
  const y = 500;
  return { x: startX + index * (w + gap), y, w, h };
}