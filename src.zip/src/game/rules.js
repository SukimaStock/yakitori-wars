import { state } from './state.js';
import { endTurn } from './flow.js';

export function getCookStatus(lane) {
    const cv = lane.cook;
    const isWeak = (lane.type === "weak");
    
    // ルールの完全統一
    if (isWeak) {
        if (cv >= 8) return "BURNT";
        if (cv >= 6) return "PERFECT"; // 6〜7
        if (cv === 5) return "OKAY";
        return "RAW";
    } else {
        if (cv >= 7) return "BURNT";
        if (cv === 6) return "PERFECT";
        if (cv === 5) return "OKAY";
        return "RAW";
    }
}

export function canMeat(playerId) { return state.players[playerId - 1].meat < 2; }

export function canPut(playerId, laneId) {
    const lane = state.lanes.find(l => l.id === laneId);
    return state.players[playerId - 1].meat > 0 && lane && lane.owner === null;
}

export function canUchiwa(playerId, laneId) { 
    return state.lanes.find(l => l.id === laneId).owner !== null;
}

export function canServe(playerId, laneIndex) {
    const lane = state.lanes[laneIndex];
    if (!lane || !lane.owner) return false;
    const status = getCookStatus(lane);
    if (status === "RAW" || status === "BURNT") return false;
    if (lane.owner !== playerId && state.players[playerId - 1].meat < 1) return false;
    return true;
}

export function canDiscard(playerId, laneIndex) {
    const lane = state.lanes[laneIndex];
    return lane && lane.owner !== null && getCookStatus(lane) === "BURNT";
}

export function actionMeat(playerId) {
    if (!canMeat(playerId)) return false;
    state.players[playerId - 1].meat += 1;
    // 肉上昇エフェクト
    state.visuals.floaters.push({ type: 'meat_up', targetType: playerId === 1 ? 'p1' : 'p2', startTime: performance.now() });
    endTurn();
    return true;
}

export function actionPut(playerId, laneId) {
    if (!canPut(playerId, laneId)) return false;
    const lane = state.lanes.find(l => l.id === laneId);
    state.players[playerId - 1].meat -= 1;
    
    // 肉落下エフェクト
    state.visuals.floaters.push({ type: 'meat_down', targetType: playerId === 1 ? 'p1' : 'p2', startTime: performance.now() });
    
    lane.owner = playerId;
    lane.cook = 0;
    lane.uchiwaBoost = 0;
    lane.justPlaced = true;
    
    state.visuals.placedAt[laneId] = performance.now();
    endTurn();
    return true;
}

export function actionUchiwa(playerId, laneId) {
    if (!canUchiwa(playerId, laneId)) return false;
    state.lanes.find(l => l.id === laneId).uchiwaBoost += 1;
    endTurn();
    return true;
}

export function actionServe(playerId, laneIndex) {
    if (!canServe(playerId, laneIndex)) return false;
    const player = state.players[playerId - 1];
    const lane = state.lanes[laneIndex];
    const status = getCookStatus(lane);
    
    if (lane.owner !== playerId) {
        player.meat -= 1;
        state.visuals.floaters.push({ type: 'meat_down', targetType: playerId === 1 ? 'p1' : 'p2', startTime: performance.now() });
    }
    
    let points = 0;
    if (status === "PERFECT") points = (lane.type === "weak") ? 12 : (lane.type === "strong" ? 6 : 8);
    else if (status === "OKAY") points = (lane.type === "weak") ? 3 : 2;

    player.score += points;
    
    // スコア上昇エフェクト（星）
    if (points > 0) {
        state.visuals.floaters.push({ type: 'star_up', amount: points, targetType: 'lane', targetIndex: laneIndex, color: status === "PERFECT" ? "#ff4" : "#f90", startTime: performance.now() });
    }
    
    state.visuals.ghosts.push({ laneIndex, status, startTime: performance.now() });
    
    lane.owner = null;
    lane.cook = 0;
    lane.uchiwaBoost = 0;
    lane.justPlaced = false;
    endTurn();
    return true;
}

export function actionDiscard(playerId, laneIndex) {
    if (!canDiscard(playerId, laneIndex)) return false;
    const lane = state.lanes[laneIndex];
    state.visuals.ghosts.push({ laneIndex, status: "BURNT", startTime: performance.now() });
    
    lane.owner = null;
    lane.cook = 0;
    lane.uchiwaBoost = 0;
    lane.justPlaced = false;
    endTurn();
    return true;
}