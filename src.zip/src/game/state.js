export const state = {
  screen: "title",
  gameMode: "survival",
  currentStage: 1,
  enemyName: "KENTA",

  round: 1,
  maxRounds: 13,
  currentPlayer: 1,
  gameOver: false,
  winner: null,

  isBusy: false,
  turnSplashTimer: 0,
  pendingTurnSplash: false,
  pendingAiBreath: false,
  pendingPlayer: null,
  aiBreathTimer: 0, // ★追加: AIターン開始時の「間」
  
  buildMode: null,

  players: [
      { id: 1, score: 0, meat: 0 },
      { id: 2, score: 0, meat: 0 }
  ],
  
  lanes: [
    { id: "s1", fire: 1, type: "weak", owner: null, cook: 0, uchiwaBoost: 0, justPlaced: false },
    { id: "s2", fire: 2, type: "medium", owner: null, cook: 0, uchiwaBoost: 0, justPlaced: false },
    { id: "s3", fire: 3, type: "strong", owner: null, cook: 0, uchiwaBoost: 0, justPlaced: false }
  ],

  // ★追加: 描画エフェクト用のタイムスタンプや一時データ
  visuals: {
      buttonClicks: {},
      buttonErrors: {},
      laneErrors: {},
      laneFlashes: {},
      placedAt: {},
      ghosts: [],
      floaters: []
  }
};

export function resetGameState() {
  state.round = 1;
  state.currentPlayer = 1;
  state.gameOver = false;
  state.winner = null;
  state.isBusy = false;
  state.turnSplashTimer = 0;
  state.pendingTurnSplash = false;
  state.pendingAiBreath = false;
  state.pendingPlayer = null;
  state.aiBreathTimer = 0;
  state.buildMode = null;
  state.visuals = {
      buttonClicks: {}, buttonErrors: {}, laneErrors: {}, laneFlashes: {}, placedAt: {}, ghosts: [], floaters: []
  };
  state.players.forEach(p => { p.score = 0; p.meat = 0; });
  state.lanes.forEach(l => { l.owner = null; l.cook = 0; l.uchiwaBoost = 0; l.justPlaced = false; });
}