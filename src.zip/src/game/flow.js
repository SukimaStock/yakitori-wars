import { state, resetGameState } from './state.js';

export function getEnemyNameByStage(stage) {
    const enemies = { 1: "KENTA", 2: "HIDEKI", 3: "MAKOTO", 4: "TETSUYA" };
    return enemies[stage] || "KENTA";
}

export function setupStage(stage) {
    state.currentStage = stage;
    state.enemyName = getEnemyNameByStage(stage);
}

export function startSurvivalGame() {
    state.gameMode = "survival";
    state.screen = "game";
    setupStage(1);
    resetGameState();
}

export function goToNextStage() {
    setupStage(state.currentStage + 1);
    resetGameState();
    state.screen = "game";
}

export function endTurn() {
    const nextP = state.currentPlayer === 1 ? 2 : 1;
    if (state.currentPlayer === 2) {
        advanceRound();
        if (state.gameOver) return;
    }
    state.pendingPlayer = nextP;
    state.pendingTurnSplash = true;
    if (nextP === 2) {
        state.pendingAiBreath = true;
    }
}

function advanceRound() {
    state.lanes.forEach(lane => {
        if (lane.owner !== null) {
            if (lane.justPlaced) lane.justPlaced = false;
            else {
                lane.cook += (lane.fire + lane.uchiwaBoost);
                // 8 = 完全に焦げた状態。それ以上はカウントしないことを明示
                if (lane.cook > 8) lane.cook = 8; 
            }
        }
        lane.uchiwaBoost = 0;
    });
    state.round += 1;
    if (state.round > state.maxRounds) {
        state.gameOver = true;
        state.screen = "gameover";
        const p1 = state.players[0].score;
        const p2 = state.players[1].score;
        state.winner = p1 > p2 ? "P1" : (p2 > p1 ? "P2" : "DRAW");
    }
}

export function resolvePendingTurnFlow() {
    // 演出を90フレーム(約1.5秒)に延ばし、フェードイン・アウトの余裕を持たせる
    if (state.pendingTurnSplash) {
        state.turnSplashTimer = 90; 
        state.pendingTurnSplash = false;
    }

    if (state.turnSplashTimer > 0) {
        state.turnSplashTimer--;
    } else if (state.pendingPlayer !== null) {
        state.currentPlayer = state.pendingPlayer;
        state.pendingPlayer = null;
        if (state.pendingAiBreath) {
            state.aiBreathTimer = 15; // ★追加: AI思考開始前に約0.25秒の間を空ける
            state.pendingAiBreath = false;
        }
    } else if (state.aiBreathTimer > 0) {
        state.aiBreathTimer--;
    }
}