import { state } from './state.js';
import { actionMeat, actionPut, actionServe, actionUchiwa, actionDiscard, getCookStatus, canMeat, canPut, canServe, canDiscard, canUchiwa } from './rules.js';

export function canStartAITurn() {
    return state.screen === "game" &&
           state.currentPlayer === 2 &&
           !state.isBusy &&
           !state.gameOver &&
           !state.pendingTurnSplash &&
           state.pendingPlayer === null &&
           state.turnSplashTimer === 0 &&
           state.aiBreathTimer === 0; // ★追加: 息継ぎが終わるまで待つ
}

export function playAITurn() {
    if (!canStartAITurn()) return;
    
    state.isBusy = true;
    const personality = getCurrentAIPersonality();
    
    // AIターンの開始が分かりやすいよう、少しThinking...を見せる
    setTimeout(() => {
        const bestAction = chooseBestAction(personality);
        executeAction(bestAction);
        state.isBusy = false;
    }, 600);
}

function getCurrentAIPersonality() {
    if (state.enemyName === "KENTA") return "gambler";
    if (state.enemyName === "HIDEKI") return "thief";
    if (state.enemyName === "MAKOTO") return "master";
    if (state.enemyName === "TETSUYA") return "reader";
    return "gambler";
}

function chooseBestAction(personality) {
    const candidates = buildCandidates();
    const validActions = candidates.filter(isValid);
    let bestScore = -9999;
    let bestAction = { type: "meat" };
    validActions.forEach(action => {
        let score = scoreAction(action, personality);
        score += (Math.random() * 6 - 3);
        if (score > bestScore) {
            bestScore = score;
            bestAction = action;
        }
    });
    return bestAction;
}

function buildCandidates() {
    const actions = [{ type: "meat" }];
    state.lanes.forEach((lane, index) => {
        actions.push({ type: "put", laneIndex: index, laneId: lane.id });
        actions.push({ type: "serve", laneIndex: index, laneId: lane.id });
        actions.push({ type: "discard", laneIndex: index, laneId: lane.id });
        actions.push({ type: "uchiwa", laneIndex: index, laneId: lane.id });
    });
    return actions;
}

function isValid(action) {
  if (action.type === "meat") return canMeat(2);
  if (action.type === "put") return canPut(2, action.laneId);
  if (action.type === "serve") return canServe(2, action.laneIndex);
  if (action.type === "discard") return canDiscard(2, action.laneIndex);
  if (action.type === "uchiwa") return canUchiwa(2, action.laneId);
  return false;
}

function executeAction(action) {
    if (action.type === "meat") actionMeat(2);
    else if (action.type === "put") actionPut(2, action.laneId);
    else if (action.type === "serve") actionServe(2, action.laneIndex);
    else if (action.type === "discard") actionDiscard(2, action.laneIndex);
    else if (action.type === "uchiwa") actionUchiwa(2, action.laneId);
}

function scoreAction(action, personality) {
    let score = 0;
    
    if (action.type === "meat") score = 10;
    if (action.type === "put") score = 20;
    if (action.type === "serve") {
        const status = getCookStatus(state.lanes[action.laneIndex]);
        if (status === "PERFECT") score = 100;
        if (status === "OKAY") score = 30;
    }
    if (action.type === "uchiwa") score = 15;
    if (action.type === "discard") score = 5;

    // ★ AIの未来予測ロジックを追加
    // ServeとDiscard以外（ターンを消費する行動）を選んだ場合、次ターンに串がどうなるか評価
    if (action.type !== "serve" && action.type !== "discard") {
        state.lanes.forEach(lane => {
            if (lane.owner === 2) { // AI自身の串
                const isWeak = (lane.type === "weak");
                const nextCook = lane.cook + lane.fire; // 次のターンの予測値
                
                // 次ターンでPERFECTになるなら高評価
                if (nextCook === 6 || (isWeak && nextCook === 7)) {
                    score += 80; 
                }
                // 次ターンで焦げるなら強いマイナス評価（回収を優先させる）
                if (!isWeak && nextCook >= 7) {
                    score -= 100;
                }
                if (isWeak && nextCook >= 8) {
                    score -= 100;
                }
            }
        });
    }

    return score;
}