import { state } from './state.js';
import { actionMeat, actionPut, actionServe, actionUchiwa, actionDiscard, canMeat, canPut, canServe, canDiscard, canUchiwa } from './rules.js';
import { startSurvivalGame } from './flow.js';
import { getLaneBounds, getButtonBounds, LAYOUT } from '../render/layout.js';

export function isPlayerInputLocked() {
    return state.screen !== "game" ||
           state.currentPlayer !== 1 ||
           state.isBusy ||
           state.pendingPlayer !== null ||
           state.turnSplashTimer > 0 ||
           state.gameOver;
}

export function canSelectAction(actionId) {
    if (actionId === "meat") return canMeat(1);
    for (let i = 0; i < state.lanes.length; i++) {
        if (isLaneValidForAction(i, actionId)) return true;
    }
    return false;
}

export function isLaneValidForAction(laneIndex, actionId) {
    const laneId = state.lanes[laneIndex].id;
    if (actionId === "put") return canPut(1, laneId);
    if (actionId === "uchiwa") return canUchiwa(1, laneId);
    if (actionId === "harvest") return canServe(1, laneIndex) || canDiscard(1, laneIndex);
    return false;
}

export function handleCanvasClick(event, canvas) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    if (state.screen === "title") { startSurvivalGame(); return; }
    else if (state.screen === "gameover") { state.screen = "title"; return; }

    if (isPlayerInputLocked()) return;

    for (let i = 0; i < LAYOUT.BUTTONS.length; i++) {
        const b = getButtonBounds(i);
        if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
            handleActionButtonClick(LAYOUT.BUTTONS[i].id);
            return;
        }
    }

    if (state.buildMode) {
        for (let i = 0; i < state.lanes.length; i++) {
            const l = getLaneBounds(i);
            if (x >= l.x && x <= l.x + l.w && y >= l.y && y <= l.y + l.h) {
                tryExecuteSelectedAction(i);
                return;
            }
        }
        state.buildMode = null;
    }
}

function handleActionButtonClick(actionId) {
    if (!canSelectAction(actionId)) {
        state.visuals.buttonErrors[actionId] = performance.now(); // ★失敗フィードバック
        return;
    }
    
    state.visuals.buttonClicks[actionId] = performance.now(); // ★クリックフィードバック

    if (actionId === "meat") {
        actionMeat(1);
        state.buildMode = null; 
    } else {
        state.buildMode = (state.buildMode === actionId) ? null : actionId;
    }
}

function tryExecuteSelectedAction(laneIndex) {
    if (!isLaneValidForAction(laneIndex, state.buildMode)) {
        state.visuals.laneErrors[laneIndex] = performance.now(); // ★レーンエラー振動
        return;
    }

    const laneId = state.lanes[laneIndex].id;
    const actionId = state.buildMode;
    
    // ★レーン選択成功時のフラッシュ
    state.visuals.laneFlashes[laneId] = performance.now();
    
    let success = false;
    if (actionId === "put") success = actionPut(1, laneId);
    else if (actionId === "uchiwa") success = actionUchiwa(1, laneId);
    else if (actionId === "harvest") {
        if (canServe(1, laneIndex)) success = actionServe(1, laneIndex);
        else if (canDiscard(1, laneIndex)) success = actionDiscard(1, laneIndex);
    }

    if (success) state.buildMode = null;
}