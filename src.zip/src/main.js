import { state } from './game/state.js';
import { playAITurn } from './game/ai.js';
import { resolvePendingTurnFlow } from './game/flow.js';
import { render } from './render/render.js';
import { LAYOUT } from './render/layout.js';
import { handleCanvasClick } from './game/input.js'; // ★追加

const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
document.body.appendChild(canvas);

canvas.width = LAYOUT.CANVAS_WIDTH;
canvas.height = LAYOUT.CANVAS_HEIGHT;

document.body.style.margin = "0";
document.body.style.backgroundColor = "#111";
document.body.style.display = "flex";
document.body.style.justifyContent = "center";
document.body.style.alignItems = "center";
document.body.style.height = "100vh";

function loop() {
    resolvePendingTurnFlow();
    render(ctx);
    playAITurn();
    requestAnimationFrame(loop);
}

// ★マウスクリック操作を input.js に完全に委譲
canvas.addEventListener('click', (e) => {
    handleCanvasClick(e, canvas);
});

// ※ 旧キーボード操作リスナーは削除し、クリック操作へ一本化しました

loop();